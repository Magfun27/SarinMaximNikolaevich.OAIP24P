from flask import Flask, render_template

app = Flask(__name__)

movies = [
    {
        "id": 1,
        "title": "Интерстеллар",
        "year": 2014,
        "rating": 8.7,
        "genre": "Фантастика",
        "description": "Команда исследователей отправляется в путешествие через червоточину, чтобы спасти человечество."
    },
    {
        "id": 2,
        "title": "Матрица",
        "year": 1999,
        "rating": 8.5,
        "genre": "Боевик",
        "description": "Хакер Нео узнает, что его мир — это компьютерная симуляция, и присоединяется к сопротивлению."
    },
    {
        "id": 3,
        "title": "Шрек",
        "year": 2001,
        "rating": 8.1,
        "genre": "Мультфильм",
        "description": "Зеленый огр отправляется в опасное путешествие, чтобы спасти принцессу Фиону от дракона."
    },
    {
        "id": 4,
        "title": "Побег из Шоушенка",
        "year": 1994,
        "rating": 9.3,
        "genre": "Драма",
        "description": "История несправедливо осужденного банкира, который не теряет надежды в стенах тюрьмы."
    },
    {
        "id": 5,
        "title": "Зеленая миля",
        "year": 1999,
        "rating": 8.4,
        "genre": "Драма",
        "description": "Надзиратель тюремного блока смертников встречает заключенного с невероятным даром исцеления."
    }
]

@app.route("/")
def index():
    return render_template("index.html", movies=movies)

@app.route("/movie/<int:movie_id>")
def movie(movie_id):
    for movie in movies:
        if movie["id"] == movie_id:
            return render_template("movie.html", movie=movie)
    return "Фильм не найден", 404

if __name__ == "__main__":
    app.run(debug=True)