from flask import render_template, Flask

app = Flask(__name__)

@app.route('/')
def index():
    a = 56
    b = 120
    c = 90
    return render_template("index.html", a=a, b=b, c=c)

@app.route('/<float:num1>/<op>/<float:num2>/')
def calculator(num1, op, num2):
    return render_template('calculator.html', num1=num1, num2=num2, op=op)

if __name__ == '__main__':
    app.run(debug=True)
